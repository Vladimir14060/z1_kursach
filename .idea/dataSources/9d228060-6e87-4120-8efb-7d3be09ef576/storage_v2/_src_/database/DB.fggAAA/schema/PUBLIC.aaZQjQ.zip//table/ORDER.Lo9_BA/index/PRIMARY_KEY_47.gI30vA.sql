create unique index PRIMARY_KEY_47
    on "ORDER" (ID);

